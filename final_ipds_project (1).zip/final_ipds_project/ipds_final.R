library(RSQLite)
library(ggplot2)
con = dbConnect(drv=SQLite, dbname="rates.db")

#connect to sqlite file
con = dbConnect(drv = SQLite(), dbname="rates.db")

#get a list of all tables
df.ratios <-dbGetQuery(con, "SELECT * FROM systems")

#average of ratios
df.summary <- dbGetQuery(con, "SELECT AVG(ratio) FROM systems")

#Code for Unconditioned Distribution of farebox ratio
ggplot(data = df.ratios, aes(x = ratio)) +
geom_density() +
  geom_vline(xintercept = mean(df.ratios$ratio), colour = "red",
             linetype = "dashed")

#Code for Scatter plot showing farebox ratio versus fare rates (i.e., what it costs to ride) for flat rate systems 
df.fareratio <- dbGetQuery(con, "select ratio from systems where faresystem = 'flat rate'")
df.farerates <- dbGetQuery(con, "select USDrates from systems where faresystem = 'flat rate'")

plot(df.fareratio$ratio, df.farerates$USDrates, 
     main = "Farebox Ratio vs. Fare Rates (Flat Rate Systems)", 
     xlab = "Farebox Ratio", ylab = "Fare Rates"
)

#Code to create a facet plot of the distribution of farebox ratios, by fare system  
library(reshape2)
library(plotly)

p <- ggplot(data = df.ratios, aes(x=ratio)) + 
  geom_density()  + 
  labs(title = "Facet Plot for Farebox Ratio by Faresystem")

# Divide by day, going horizontally and wrapping with 4 columns
p <- p + facet_wrap( ~ faresystem, ncol=5) 
p <- ggplotly(p)

#Create a faceted plot showing the distribution of farebox ratios by continent (use a histogram or density)
h <- ggplot(data = df.ratios, aes(x=ratio)) + 
  labs(title = "Facet Plot for Farebox Ratio by Continent") + 
  geom_histogram(aes(y=..density..), colour="black", fill="white")+
  geom_density(alpha=.2, fill="#FF6666") 

h <- h + facet_wrap( ~ continent, ncol=5) 
h <- ggplotly(h)




#Prediction Model 
m <- lm(ratio ~ year + faresystem, data = df.ratios) 
summary(m)

df.ratios$predicted <- predict(m)

y = ggplot(data=df.ratios, aes(x=year, y=ratio)) + 
  geom_point() + geom_line(aes(x=year, y=predicted, linetype = faresystem, colour = faresystem))+
  theme(legend.position = "none")+theme_classic()+ggtitle("Predicted Ratios on Year and Fare Type")

